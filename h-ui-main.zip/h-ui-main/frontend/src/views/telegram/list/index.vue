<template>
  <div>telegram list</div>
</template>

<script lang="ts">
export default {
  name: "index",
};
</script>

<script setup lang="ts"></script>

<style scoped></style>
