package main

import "h-ui/cmd"

func main() {
	cmd.Execute()
}
