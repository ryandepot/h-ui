package constant

const (
	Shadowrocket = "shadowrocket"
	Clash        = "clash"
	V2rayN       = "v2rayn"
)
