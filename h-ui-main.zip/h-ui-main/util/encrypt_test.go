package util

import "testing"

func TestSHA224String(t *testing.T) {
	println(SHA224String("sysadmin"))
}
